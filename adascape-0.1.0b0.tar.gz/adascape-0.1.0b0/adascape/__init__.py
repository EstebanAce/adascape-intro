from .base import IR12SpeciationModel
from .tree import PTreeAccessor as _PTreeAccessor


__version__ = "0.1.0"
